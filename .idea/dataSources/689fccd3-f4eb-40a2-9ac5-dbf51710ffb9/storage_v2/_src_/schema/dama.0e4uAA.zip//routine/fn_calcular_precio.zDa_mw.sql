create
    definer = root@localhost function fn_calcular_precio(p_id_pista int, p_inicio datetime, p_fin datetime) returns decimal(10, 2)
    deterministic
BEGIN
    DECLARE v_precio_base DECIMAL(10,2);
    DECLARE v_horas DECIMAL(10,2);

    -- Obtiene precio base de la pista
    SELECT precio_base INTO v_precio_base
    FROM pistas
    WHERE id = p_id_pista;

    -- Calcula horas (mínimo 1)
    SET v_horas = TIMESTAMPDIFF(MINUTE, p_inicio, p_fin) / 60;
    IF v_horas < 1 THEN
        SET v_horas = 1;
    END IF;

    RETURN v_horas * v_precio_base;
END;

