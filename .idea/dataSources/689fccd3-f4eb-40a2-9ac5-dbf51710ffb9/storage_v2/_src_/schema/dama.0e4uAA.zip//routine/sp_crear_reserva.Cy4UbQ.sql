create
    definer = root@localhost procedure sp_crear_reserva(IN p_id_pista int, IN p_id_socio int, IN p_inicio datetime,
                                                        IN p_fin datetime, OUT p_precio decimal(10, 2))
BEGIN
    -- Calcula precio usando la función
    SET p_precio = fn_calcular_precio(p_id_pista, p_inicio, p_fin);

    -- Inserta reserva
    INSERT INTO reservas(id_socio, id_pista, inicio, fin, precio)
    VALUES (p_id_socio, p_id_pista, p_inicio, p_fin, p_precio);
END;

